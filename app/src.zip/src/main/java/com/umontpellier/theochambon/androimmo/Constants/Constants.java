package com.umontpellier.theochambon.androimmo.Constants;

/**
 * Created by theo on 01/12/2015.
 */
public abstract class Constants {
    public static final String serverURL = "http://theochamb1.freeheberg.org/";
    public static final String serverImageURL = "http://149.202.51.217/serveurTheo/uploadImage.php";
    public static final String uploadDirectory = "http://149.202.51.217/serveurTheo/upload/";
}
